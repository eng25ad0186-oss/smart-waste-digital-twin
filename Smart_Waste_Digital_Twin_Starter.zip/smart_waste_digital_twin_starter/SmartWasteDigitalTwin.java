// Starter scaffold only — implement the logic yourself during the event.
// Do not submit a pre-built solution if the event rules require code to be written on-site.

public class SmartWasteDigitalTwin {
    public static void main(String[] args) {
        // TODO 1: Define a Bin class or record with id, location, category, and fill percentage.
        // TODO 2: Validate fill percentage (0 through 100).
        // TODO 3: Implement a status rule for NORMAL, ATTENTION, and COLLECTION_NEEDED.
        // TODO 4: Create sample simulated bins.
        // TODO 5: Print a collection-priority list.
        // TODO 6: Add summary metrics and test boundary cases.
    }
}
