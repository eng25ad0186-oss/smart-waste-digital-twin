# Smart Waste Management Digital Twin — Starter

This is a starter scaffold, not a finished hackathon solution. Follow the event rules: write your project implementation during the event and do not submit pre-built code as event work.

## Suggested first implementation
1. Create a `Bin` class with id, location, category and fill percentage.
2. Validate fill percentage is 0–100.
3. Add a method that returns `NORMAL`, `ATTENTION`, or `COLLECTION_NEEDED`.
4. Create a small list of simulated bins.
5. Sort bins needing collection by fill level.
6. Add a dashboard only after the Java logic works.

## Suggested example thresholds
- 0–59%: NORMAL
- 60–79%: ATTENTION
- 80–100%: COLLECTION_NEEDED

These are example thresholds for a prototype, not industry standards. Label simulated data clearly.
